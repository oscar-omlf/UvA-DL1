STANDARD = "standard"
FGSM = "fgsm"
PGD= "pgd"
CIFAR10_LABELS = ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']
ALPHA = "alpha"
EPSILON = "epsilon"
NUM_ITER = "num_iter"