# Assignment 3, Part 2:
Make sure the gpu environment is properly installed before running this code. 

train.py is the file to call to train and test models, nothing needs to be changed here for the purposes of the assignments, but take a look at it to understand how to call different implementations and hyperparameters.

adverserial_attack.py is where most of the magic happens, and you have to implement the most

utils.py has utility functions and the main training loop, you only need to implement a small part here

globals.py saves some strings in variable names for easier debugging